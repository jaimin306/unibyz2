<?php
$name='TERAFONT-CHANDAN';
$type='TTF';
$desc=array (
  'Ascent' => 834,
  'Descent' => -279,
  'CapHeight' => 834,
  'Flags' => 4,
  'FontBBox' => '[-490 -279 944 834]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 762,
);
$up=-100;
$ut=50;
$ttffile='/var/www/html/sachin/rmts/mpdf/ttfonts/chandan.ttf';
$TTCfontID='0';
$originalsize=59048;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='chandan';
$panose=' 0 0 0 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>