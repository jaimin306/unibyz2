<?php

$html = '
<style>
body { 	font-family: sans; }
h4, p {	margin: 0pt;
}
h5 { margin-bottom: 0; }

@page {
	//background-gradient: linear #00FFFF #FFFF00 0 0.5 1 0.5;
	odd-header-name: html_myHTMLHeaderOdd;
	even-header-name: html_myHTMLHeaderEven;
	odd-footer-name: html_myHTMLFooterOdd;
	even-footer-name: html_myHTMLFooterEven;
}
.arial{
	font-family:Arial;
	font-size:13px;
}
.arial-bold{
	font-family:Arial;
	font-size:13px;
	font-weight:900;
}
h2 { color: #880000; margin-bottom: 0.2em; }
h4 { margin-bottom: 0.2em; }
</style>

<div lang="gu"><h3 style="text-decoration:underline;text-align:center">હુકમ  </h3></div>

<div class="indic">
<h6 class="arial" style="text-decoration:underline; font-weight:500">RRL / Order No. :- 92, Dt. 05/07/2016</h6>

<p lang="gu"><span class="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dy. G.M (Admin & Finance)</span> 
&#xAA4;&#xABE;. 
<span class="arial"> 05/07/2016 </span>
&#xAA8;&#xAC1;&#xA82; &#xAA8;&#xABF;&#xAB5;&#xAC7;&#xAA6;&#xAA8; &#xAB2;&#xA95;&#xACD;&#xAB7; &#xAAE;&#xABE;&#xA82; &#xAB2;&#xAC7;&#xAB5;&#xABE;&#xAAE;&#xABE;&#xA82; &#xA86;&#xAB5;&#xAC7;&#xAB2; &#xA9B;&#xAC7;. <br> કામ ની વિગત  :
<span class="arial"> RRL </span>
&#xAA6;&#xACD;&#xAB5;&#xABE;&#xAB0;&#xABE; &#xAB0;&#xABE;&#xA9C;&#xA95;&#xACB;&#xA9F; &#xAB6;&#xAB9;&#xAC7;&#xAB0;&#xAC0; &#xAAC;&#xAB8; <!-- Service Start -->&#xAB8;&#xAB0;&#xACD;&#xAB5;&#xABF;&#xAB8; સર્વિસ  <!-- service end-->&#xA85;&#xA82;&#xAA4;&#xAB0;&#xACD;&#xA97;&#xAA4; &#xAAE;&#xABE;&#xA82;&#xAB9;&#xAC7; &#xA9C;&#xAC2;&#xAA8; - 
<span class="arial">2016</span>
&#xAA8;&#xACB; &#xAAA;&#xAC7;&#xAB8;&#xAC7;&#xAA8;&#xACD;&#xA9C;&#xAB0; &#xA9F;&#xAC7;&#xA95;&#xACD;&#xAB7; &#xAA8;&#xAC0; &#xA9A;&#xAC1;&#xA95;&#xAB5;&#xAA3;&#xAC0; &#xA95;&#xAB0;&#xAB5;&#xABE; &#xAAC;&#xABE;&#xAAC;&#xAA4;&#xAC7; 
<br><br>
&#xA95;&#xABE;&#xAAE; &#xAA8;&#xAC1;&#xA82; &#xAAC;&#xA9C;&#xAC7;&#xA9F; &#xAAB;&#xA82;&#xAA1; : 
<span class="arial">CITY BUS / RTO Passenger tax</span><br><br><br>

<div align="center" lang="gu">&#xA86; &#xAAC;&#xA9C;&#xAC7;&#xA9F; &#xAB8;&#xAA6;&#xAB0; &#xAA8;&#xAC0; &#xA85;&#xAA4;&#xACD;&#xAAF;&#xABE;&#xAB0;&#xAC7; &#xAA8;&#xAC0; &#xAB8;&#xACD;&#xAA5;&#xABF;&#xAA4;&#xABF; &#xAA8;&#xAC0;&#xA9A;&#xAC7; &#xAAE;&#xAC1;&#xA9C;&#xAAC; &#xA9B;&#xAC7;. </div>
<br><br>
<table width="70%" >
	<tr>
		<td><span lang="gu">&#xAAC;&#xA9C;&#xAC7;&#xA9F; &#xAAE;&#xABE;&#xA82; &#xAAE;&#xA82;&#xA9C;&#xAC1;&#xAB0; &#xAA5;&#xAAF;&#xAC7;&#xAB2;&#xAC0; &#xAB0;&#xA95;&#xAAE; </span></td>
		<td><span class="arial-bold"> Rs. </span></td>
		<td><span class="arial-bold"> 8,03,000 /-</span></td>
	</tr>
	<tr>
		<td><span lang="gu">&#xA85;&#xAA4;&#xACD;&#xAAF;&#xABE;&#xAB0; &#xAB8;&#xAC1;&#xAA7;&#xAC0; &#xA96;&#xAB0;&#xACD;&#xA9A; &#xAA8;&#xAC0; &#xAB0;&#xA95;&#xAAE; :-</span> </td>
		<td><span class="arial-bold"> Rs. </span></td>
		<td><span class="arial-bold"> 8,03,000 /-</span></td>
	</tr>
	<tr>
		<td><span lang="gu"> &#xA85;&#xAA4;&#xACD;&#xAAF;&#xABE;&#xAB0; &#xAB8;&#xAC1;&#xAA7;&#xAC0; &#xA95;&#xAAE;&#xAC0;&#xA9F;&#xAAE;&#xAC7;&#xAA8;&#xACD;&#xA9F; &#xAA8;&#xAC0; &#xAB0;&#xA95;&#xAAE; :-
</span> </td>
		<td><span class="arial-bold"> Rs. </span></td>
		<td><span class="arial-bold"> 8,03,000 /-</span></td>
	</tr>
	<tr>
		<td><span lang="gu"> &#xA8F;&#xAB8;&#xACD;&#xA9F;&#xAC0;&#xAAE;&#xAC7;&#xA9F; &#xAA8;&#xAC0; &#xAB0;&#xA95;&#xAAE; : - </span> </td>
		<td><span class="arial-bold"> Rs. </span></td>
		<td><span class="arial-bold"> 8,03,000 /-</span></td>
	</tr>
	<tr>
		<td><span lang="gu">&#xA95;&#xAC1;&#xAB2; &#xA96;&#xAB0;&#xACD;&#xA9A; &#xAA8;&#xAC0; &#xAB0;&#xA95;&#xAAE; : - </span></td>
		<td><span class="arial-bold"> Rs. </span></td>
		<td><span class="arial-bold"> 8,03,000 /-</span></td>
	</tr>
	<tr>
		<td><span lang="gu"> &#xA95;&#xAC1;&#xAB2; &#xAAC;&#xABE;&#xA95;&#xAC0; &#xAB0;&#xA95;&#xAAE; : - </span> </td>
		<td><span class="arial-bold"> Rs. </span></td>
		<td><span class="arial-bold"> 8,03,000 /-</span></td>
	</tr>
</table>
<br><br>

<div style="margin-left:30px">&#8226; <span class="arial">As Per approval of Board of Directors - RRL (Full power for payment for Administration works),Dated 29.11.2012.</span></div>
<br>

<div style="margin-left:30px">&#8226; <span class="arial">As Per approval of Board of Directors to approve budget and Sanction expense dated 31/03/2016.</span></div>
<br>

<div style="margin-left:30px">&#8226; <span class="arial">RMC General Board Resolution no. 86, dated 19/02/2016 for allocation of fund to RRL. </span></div>
<br><br><br><br>


<table  width="100%">
<tr>
	<td><span class="arial">Commitment No :</span></td>
	<td colspan="2" align="right"><span class="arial">General Manager &nbsp;&nbsp;&nbsp;</span><br><span class="arial">Rajkot Rajpath Limited </span></td>
</tr>
</table>

</p>
';


//==============================================================
//==============================================================
//==============================================================
include("mpdf.php");

$mpdf=new mPDF(); 

$mpdf->SetDisplayMode('fullpage');

$mpdf->WriteHTML($html);

$mpdf->Output('order.pdf','F'); 

exit;

//==============================================================
//==============================================================
//==============================================================
//==============================================================


?>