<footer class="main-footer">
    <div class="pull-right hidden-xs"> <b>Version</b> 2.4.0 </div>
    <strong>Copyright &copy; 2017 <a href="http://unilyzeyourbusiness.com">unilyze</a>.</strong> All rights
    reserved. 
</footer>

    

