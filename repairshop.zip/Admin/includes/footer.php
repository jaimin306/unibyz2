<footer class="main-footer">
    <div class="pull-right hidden-xs"> <b>Version</b> 2.4.0 </div>
    <strong>Copyright &copy; 2017 <a href="https://unibyz.com">Unibyz.com</a>.</strong> All rights
    reserved. 
</footer>

    

